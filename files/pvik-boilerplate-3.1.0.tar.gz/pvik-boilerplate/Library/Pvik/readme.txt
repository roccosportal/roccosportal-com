Pvik

Version: 6.1.0
License: license.txt
Date: 25-05-2013 (dd-mm-yyyy)

Pvik is a free small php framework which uses the MVC concept.
You find more information in the wiki (github.com/roccosportal/pvik/wiki)

