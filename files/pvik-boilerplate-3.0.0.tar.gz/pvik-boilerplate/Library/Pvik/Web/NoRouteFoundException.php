<?php

namespace Pvik\Web;

/**
 * Exception when no route was found.
 */
class NoRouteFoundException extends \Exception {
    
}
