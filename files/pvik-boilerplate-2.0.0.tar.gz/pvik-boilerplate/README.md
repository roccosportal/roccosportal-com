PvikBoilerplate
========

This is the boilerplate for Pvik.

PvikBoilerplate-Version: 2.0.0

Pvik-Version: 5.0.0

Pvik-Wiki: https://github.com/roccosportal/pvik/wiki
