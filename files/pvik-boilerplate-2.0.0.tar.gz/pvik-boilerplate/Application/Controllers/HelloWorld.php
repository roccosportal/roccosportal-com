<?php

namespace MyProject\Controllers;

class HelloWorld extends \Pvik\Web\Controller {
    public function IndexAction(){
        
        $this->ExecuteView();
    }
}