<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
    "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>Under Construction</title>
    <style type="" >
/* reset */
a, h1, h2, h3, h4, h5, h6, p, div, body, ul, li, span, b, table, th, td, tr, em, html, pre, code, blockquote{
	margin:0px;
	padding:0px;
	border: 0px;
	font-size: 100%;
	font: inherit;
	vertical-align: baseline;
}
a {text-decoration:none;}
ul {list-style-type: none;}
table {
	border-collapse: collapse;
	border-spacing: 0;
}

/* formatting */
body {font-family: "Courier New";color:black;font-size: 12px;}
#content {width: 500px;margin: 40px auto ;}

h1 {font-weight:bold;}
h1 {font-size:24px;}
p {margin: 20px 5px;}
img {margin: 0px 15px;float: left;}
</style>
</head>
<body>
<div id="content">
<h1>Under Construction</h1>
<p><img alt="" src="<?php echo \Pvik\Core\Path::RelativePath('~/img/under-construction.jpg') ?>" />Sorry, but this page is currently unavailable during a normal update proccess. Please try it in a few minutes again. You can contact me via my email address: admin@website.com. Feel free to ask anything.</p>
</div>
</body>
</html>

