<?php

namespace Pvik\Database\SQLSRV;

/**
 * Builds sql statements according to sqlsrv sql.
 */
class Builder extends \Pvik\Database\MSSQL\Builder {
    
}